#ifndef _IMPORT_DA_H
#define _IMPORT_DA_H
#ifdef USE_DEVICEATLAS

#include <types/global.h>
#include <dac.h>

int init_deviceatlas(void);
void deinit_deviceatlas(void);
#endif
#endif
